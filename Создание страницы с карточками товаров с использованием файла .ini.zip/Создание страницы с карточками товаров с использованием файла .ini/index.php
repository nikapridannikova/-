<?php
// Function to load products from INI file
function load_products_from_ini($filename) {
    $products = parse_ini_file($filename, true);
    return $products;
}

// Function to display a single product card
function display_product_card($product) {
    echo '<div class="product-card">';
    echo '<h2>' . htmlspecialchars($product['name']) . '</h2>';
    echo '<p>' . htmlspecialchars($product['description']) . '</p>';
    echo '<p>Price: $' . htmlspecialchars($product['price']) . '</p>';
    echo '<p>Stock: ' . htmlspecialchars($product['stock']) . '</p>';
    echo '</div>';
}

// Function to display all products
function display_all_products($products) {
    foreach ($products as $product) {
        display_product_card($product);
    }
}

// Load products and display them
$products = load_products_from_ini('products.ini');
display_all_products($products);
?>