function display_product_card($product) {
    echo '<div class="product-card">';
    echo '<h2>' . htmlspecialchars($product['name']) . '</h2>';
    echo '<p>ID: ' . htmlspecialchars($product['id']) . '</p>';
    echo '<p>Description: ' . htmlspecialchars($product['description']) . '</p>';
    echo '<p>Price: ' . htmlspecialchars($product['price']) . ' RUB</p>';
    echo '<p>Stock: ' . htmlspecialchars($product['stock']) . '</p>';
    echo '</div>';
}

